const mysql = require("mysql");
const config = require("../config");
const e = require("express");

const dbconf = {
  host: config.mysql.host,
  user: config.mysql.user,
  password: config.mysql.password,
  database: config.mysql.database,
};

let connection;

async function conMysql() {
  if (!connection) {
    connection = mysql.createConnection(dbconf);
    connection.connect((err) => {
      if (err) {
        console.log("[Error connecting to database]", err);
        return;
      }
      console.log("Database connection established");
    });

    connection.on("error", (err) => {
      console.log("[Database error]", err);
      if (err.code === "PROTOCOL_CONNECTION_LOST") {
        console.log("Reconnecting to database");
        conMysql();
      } else {
        throw err;
      }
    });
  }
  return connection;
}

conMysql();

async function all(table, next) {
  try {
    return await new Promise((resolve, reject) => {
      connection.query(`SELECT * FROM ${table}`, (err, data) => {
        return err ? reject(err) : resolve(data);
      });
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
}

async function one(table, id, next) {
  try {
    return await new Promise((resolve, reject) => {
      connection.query(`SELECT * FROM ${table} WHERE id=${id}`, (err, data) => {
        return err ? reject(err) : resolve(data);
      });
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
}

async function insert(table, data) {
  return new Promise((resolve, reject) => {
    const query = `INSERT INTO ${table} SET ?`;
    connection.query(query, data, (err, result) => {
      if (err) {
        return reject(err);
      }
      return resolve(result);
    });
  });
}

async function update(table, data) {
  return new Promise((resolve, reject) => {
    const query = `UPDATE ${table} SET ? WHERE id = ?`;
    connection.query(query, [data, data.id], (err, result) => {
      return err ? reject(err) : resolve(result);
    });
  });
}

async function add(table, data) {
  if (data && data.id) {
    const exists = await new Promise((resolve, reject) => {
      const query = `SELECT * FROM ${table} WHERE id = ?`;
      connection.query(query, data.id, (err, result) => {
        if (err) {
          return reject(err);
        }
        return resolve(result.length > 0);
      });
    });

    if (exists) {
      return update(table, data);
    }
  }
  return insert(table, data);
}

async function remove(table, id, next) {
  try {
    return await new Promise((resolve, reject) => {
      connection.query(
        `DELETE FROM ${table} WHERE id = ?`,
        [id],
        (err, result) => {
          if (err) {
            return reject(err);
          }
          if (result.affectedRows === 0) {
            return reject(new Error("No record found with this id"));
          }
          return resolve(result);
        }
      );
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
}

function query(tabla, consulta) {
  return new Promise((resolve, reject) => {
    connection.query(
      `SELECT * FROM ${tabla} WHERE ?`,
      consulta,
      (error, result) => {
        return error ? reject(error) : resolve(result);
      }
    );
  });
}

module.exports = {
  all,
  one,
  add,
  update,
  remove,
  query,
};
