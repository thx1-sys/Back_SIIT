const express = require("express");
const morgan = require("morgan");
const config = require("./config");

const error = require("./network/errors");

const client = require("./mod/client/rute");
const users = require("./mod/users/rute");
const auth = require("./mod/auth/rute");

const app = express();

// * middlewares
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// * configration
app.set("port", config.app.port);

// * routes
app.use("/api/client", client);
app.use("/api/users", users);
app.use("/api/auth", auth);
app.use(error);

module.exports = app;
